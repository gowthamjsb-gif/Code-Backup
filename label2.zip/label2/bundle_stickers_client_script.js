// Client Script for "Bundle Stickers"
// Depending on whether this is a Standalone DocType or a Child Table, use the appropriate hook:

// --- Use this if "Bundle Stickers" is a STANDALONE DocType ---
frappe.ui.form.on('Bundle Stickers', {
    print_label: function(frm) {
        frappe.generate_bundle_sticker(frm, frm.doc);
    }
});

// --- Use this if "Bundle Stickers" is a CHILD TABLE inside another DocType (e.g., Shaft Production Run) ---
// frappe.ui.form.on('Bundle Stickers', {
//     print_label: function(frm, cdt, cdn) {
//         var cur_row = locals[cdt][cdn];
//         frappe.generate_bundle_sticker(frm, cur_row);
//     }
// });

frappe.generate_bundle_sticker = function(frm, doc) {
    if (!doc) return;

    var f = frm || cur_frm;
    var job_id = doc.job_id || "";
    var item_row = ((f.doc || {}).items || []).find(function(i) { 
        return (i.job_id == job_id || i.job == job_id || i.custom_job_id == job_id || i.idx == job_id || i.name == job_id); 
    });

    frappe.prompt([
        {
            label: 'Bundled Gross Weight (Kgs)',
            fieldname: 'bundled_gw',
            fieldtype: 'Float',
            default: flt(doc.sticker_bundle_weight || 0),
            reqd: 1
        },
        {
            label: 'Bundled Net Weight (Kgs)',
            fieldname: 'bundled_nw',
            fieldtype: 'Float',
            default: item_row ? flt(item_row.net_weight) : 0,
            reqd: 1
        },
        {
            label: 'No. of Rolls',
            fieldname: 'no_of_rolls',
            fieldtype: 'Int',
            default: 1,
            reqd: 1
        }
    ], function(values) {
        var no_of_rolls = values.no_of_rolls || 1;
        var bundled_nw = flt(values.bundled_nw);
        var bundled_gw = flt(values.bundled_gw);
        var normal_nw = bundled_nw / no_of_rolls;
        var normal_gw = bundled_gw / no_of_rolls;

        var party_code = item_row ? (item_row.party_code || "") : "";
        var d = {
            company: "JAYASHREE SPUN BOND",
            quality: (item_row ? item_row.quality : "") || "NON WOVEN FABRIC",
            gsm: item_row ? item_row.gsm : "",
            color: item_row ? (item_row.color || item_row.colour) : "",
            width_val: doc.sticker_width || (item_row ? item_row.width_inch : "0"), // user's field overrides
            length: item_row ? (item_row.custom_produced_length_mtrs || "0") : "0",
            bundled_gw: bundled_gw.toFixed(2),
            bundled_nw: bundled_nw.toFixed(2),
            gw: normal_gw.toFixed(2),
            nw: normal_nw.toFixed(2),
            no_of_rolls: no_of_rolls,
            batch_no: item_row ? (item_row.batch_no || "") : (doc.job_id || ""),
            party_code: party_code, // Will be replaced by customer name if found
            barcode_data: item_row ? (item_row.batch_no || "") : (doc.job_id || "BUNDLE")
        };

        var label_type = ((f.doc || {}).custom_label || "Default").toLowerCase();
        
        var proceed_print = function() {
            if (label_type.includes("custom")) {
                flow_customized_bundle_label(d, label_type);
            } else {
                trigger_bundle_print(d, label_type);
            }
        };

        if (party_code) {
            frappe.db.get_value("Customer", party_code, "customer_name", function(r) {
                if (r && r.customer_name) {
                    d.party_code = r.customer_name;
                }
                proceed_print();
            });
        } else {
            proceed_print();
        }
    }, 'Enter Bundle Details', 'Generate Label');
};

function trigger_bundle_print(d, label_type, custom_fields) {
    var htmlContent = get_bundle_label_format(d, label_type, custom_fields);
    var printWindow = window.open('', '_blank', 'height=650,width=500');
    if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
    }
}

function flow_customized_bundle_label(d, label_type) {
    var dialog = new frappe.ui.Dialog({
        title: 'Select Fields to Print',
        fields: [
            { fieldtype: 'Check', fieldname: 'show_gsm', label: 'GSM', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_width', label: 'Width', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_length', label: 'Length', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_rolls', label: 'No of Rolls', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_bun_gw', label: 'Bundled Gross Weight', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_bun_nw', label: 'Bundled Net Weight', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_norm_gw', label: 'Normal Gross Weight', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_norm_nw', label: 'Normal Net Weight', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_batch', label: 'Batch No (Bottom)', default: 1 },
            { fieldtype: 'Check', fieldname: 'show_customer', label: 'Customer Name', default: 1 }
        ],
        primary_action_label: 'Print Label',
        primary_action: function(values) {
            dialog.hide();
            trigger_bundle_print(d, label_type, values);
        }
    });
    dialog.show();
}

function get_bundle_label_format(d, type, custom_fields) {
    type = (type || "default").trim().toLowerCase();
    var isReliance = type.includes("reliance") || type.includes("relience");
    var isPerfect = type.includes("perfect");
    var isPlainCC = type.includes("plain cc");
    var isPlain = type.includes("plain") && !isPlainCC;
    var isCustom = type.includes("custom");
    var isDefault = !isReliance && !isPerfect && !isPlainCC && !isPlain && !isCustom;

    var header = "";
    var sub1 = "";
    var sub2 = "";
    var fields = custom_fields || {
        show_gsm: 1, show_width: 1, show_length: 1, show_rolls: 1, show_bun_gw: 1, show_bun_nw: 1, show_norm_gw: 1, show_norm_nw: 1, show_batch: 1, show_customer: 1
    };

    var subOrder = "";
    if (fields.show_customer && d.party_code) {
        subOrder = " | " + d.party_code;
    }

    // Categorization identical to main label
    if (isDefault || isCustom) {
        header = "JayaShree Spun Bond";
        sub1 = "enquiry@jayashreespunbond.com";
        sub2 = d.quality + subOrder;
    } else if (isPlainCC) {
        header = "Non Woven Fabrics";
        sub1 = d.quality + subOrder;
        sub2 = "";
    } else {
        header = "Non Woven Fabrics";
        sub1 = d.quality + subOrder;
        sub2 = "";
    }

    var rows = [];
    if (fields.show_gsm) {
        rows.push('<tr><td><span class="lbl">GSM</span></td><td class="colon">:</td><td><span class="val">' + d.gsm + '</span></td></tr>');
    }

    var widthUnit = " Inches";
    var wValLower = String(d.width_val || "").toLowerCase();
    if (wValLower.includes("inches") || wValLower.includes("inch") || wValLower.includes("cm") || wValLower.includes('"')) {
        widthUnit = ""; 
    }
    if (fields.show_width) {
        rows.push('<tr><td><span class="lbl">Width</span></td><td class="colon">:</td><td><span class="val">' + d.width_val + widthUnit + '</span></td></tr>');
    }

    var lengthUnit = " Mtrs";
    var lValStr = String(d.length || "");
    if (lValStr.toLowerCase().includes("mtr")) lengthUnit = "";
    if (fields.show_length) {
        rows.push('<tr><td><span class="lbl">Length</span></td><td class="colon">:</td><td><span class="val">' + d.length + lengthUnit + '</span></td></tr>');
    }

    if (fields.show_rolls) {
        rows.push('<tr><td><span class="lbl">No of Rolls</span></td><td class="colon">:</td><td><span class="val">' + d.no_of_rolls + '</span></td></tr>');
    }
    if (fields.show_bun_gw) {
        rows.push('<tr><td><span class="lbl">Bundled G.W.</span></td><td class="colon">:</td><td><span class="val">' + d.bundled_gw + ' Kgs</span></td></tr>');
    }
    if (fields.show_bun_nw) {
        rows.push('<tr><td><span class="lbl">Bundled N.W.</span></td><td class="colon">:</td><td><span class="val">' + d.bundled_nw + ' Kgs</span></td></tr>');
    }
    if (fields.show_norm_gw) {
        rows.push('<tr><td><span class="lbl">Gross Wt / Roll</span></td><td class="colon">:</td><td><span class="val">' + d.gw + ' Kgs</span></td></tr>');
    }
    if (fields.show_norm_nw) {
        rows.push('<tr><td><span class="lbl">Net Wt / Roll</span></td><td class="colon">:</td><td><span class="val">' + d.nw + ' Kgs</span></td></tr>');
    }

    var btmRow = "";
    if (fields.show_batch) {
        btmRow = '<div class="btm-row"><span class="lbl">BATCH No : <span class="batch-val">' + d.batch_no + '</span></span></div>';
    }

    var labelStyle = isPerfect ? 'font-size: 1.1em;' : 'font-size: 1.05em;';
    var headerSize = isPerfect ? 'font-size: 26px;' : 'font-size: 24px;';

    return '<html><head><title>Bundle Label Preview</title><style>' +
        '@media print { .btn-panel { display: none !important; } @page { size: 4in 4in; margin: 0; } body { margin: 0; } }' +
        'body { font-family: "Arial", sans-serif; margin: 0; padding: 0; text-align: center; background: #eee; ' + labelStyle + ' }' +
        '.btn-panel { padding: 10px; background: #eee; }' +
        '.sticker { width: 4in; height: 4in; margin: 20px auto; border: 2px solid black; background: white; box-sizing: border-box; display: flex; flex-direction: column; overflow: hidden; }' +
        '.inner-border { border: 2px solid black; margin: 6px; padding: 6px 10px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; }' +
        '.header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 4px; margin-bottom: 4px; }' +
        '.company { ' + headerSize + ' font-weight: 900; letter-spacing: 0.5px; margin-bottom: 1px; }' +
        '.email { font-size: 12px; font-weight: bold; color: #444; margin-bottom: 1px; }' +
        '.subheader { font-size: 15px; font-weight: 900; color: black; letter-spacing: 0.5px; margin-top: 1px; }' +
        '.table-container { flex-grow: 1; display: flex; flex-direction: column; justify-content: center; margin: 2px 0; }' +
        'table { width: 100%; border-collapse: collapse; margin: 0 auto; }' +
        'td { padding: 3px 0; vertical-align: middle; border: none; text-align: left; }' +
        'td:nth-child(1) { width: 44%; padding-left: 8px; }' +
        'td.colon { width: 5%; text-align: center; font-weight: bold; font-size: 14px; }' +
        'td:nth-child(3) { width: 51%; padding-left: 4px; }' +
        '.lbl { font-size: 14px; font-weight: 900; color: #333; }' +
        '.val { font-size: 14px; font-weight: 900; color: #000; }' +
        '.btm-row { display: flex; justify-content: center; align-items: center; border-top: 2px dashed #666; padding-top: 4px; margin: 2px 0; }' +
        '.btm-row .lbl { font-size: 14px; }' +
        '.btm-row .batch-val { font-weight: 900; color: #000; font-size: 16px; }' +
        '.barcode-container { display: flex; justify-content: center; align-items: center; padding: 2px 0 0 0; }' +
        '#barcode { max-width: 100%; height: 50px; }' +
        '</style></head><body>' +
        '<div class="btn-panel"><button onclick="window.print()" style="padding:10px 20px; font-weight:bold; cursor:pointer;">PRINT</button><button onclick="window.close()" style="padding:10px 20px; margin-left:10px;">CLOSE</button></div>' +
        '<div class="sticker"><div class="inner-border">' +
        '<div class="header"><div class="company">' + header + '</div><div class="email">' + sub1 + '</div>' + (sub2 ? '<div class="subheader">' + sub2 + '</div>' : '') + '</div>' +
        '<div class="table-container"><table>' + rows.join('') + '</table></div>' +
        btmRow +
        '<div class="barcode-container"><svg id="barcode"></svg></div>' +
        '</div></div>' +
        '<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>' +
        '<script>JsBarcode("#barcode", "' + d.barcode_data + '", { format: "CODE128", displayValue: true, fontSize: 11, textMargin: 1, height: 45, width: 1.8, margin: 0 });</script>' +
        '</body></html>';
}
